﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TestApp;
using System.Linq;
using System.ComponentModel;
using System.Runtime.InteropServices;
using System.Security.Cryptography.X509Certificates;

namespace TestApp
    {
        internal class Program
        {
            static void Main(string[] args)
            {
                //POE (PART 1+2)

                External obj = new External(); //EXTERNAL CLASS OBJECT REFERENCE

                int NumberOfIngredients = 0, NumberOfsteps = 0; ;
                List<int> IngredientQuantities = new List<int>();
                List<string> RecipeSteps = new List<string>();
                int WhileLoopNumber = 0;
                string recipeName = "";
                List<string> IngredientNames = new List<string>();
                List<string> IngredientUnitofMeasure = new List<string>();
                List<int> Calories = new List<int>();
                List<string> FoodGroup = new List<string>();
                int TotalCalories = 0;


            while (WhileLoopNumber != 1)
                {

                    //THE FOLLOWING ARE THE MENU OPTIONS THAT WILL BE AVAILABLE TO THE USER
                    Console.WriteLine("Welcome to your cookbook \n" +
                                      "\n" +
                                      "(1) Add new recipe \n" +
                                      "(2) Display recip details \n" +
                                      "(3) Scale the recipe quantities \n" +
                                      "(4) Reset the quantities to original values \n" +
                                      "(5) Clear all existing data \n" +
                                      "(6) Exit");

                    int MenuSelection = Convert.ToInt32(Console.ReadLine()); //THE MENU SELECTION CHOSEN BY THE USER

                if (MenuSelection == 1)
                {
            
                    //obj.RecipeInformation(IngredientQuantities, NumberOfIngredients, IngredientNames, recipeName);

                    Console.WriteLine("Enter a name for your recipe:"); //THE NAME FOR THE RECIPE
                    recipeName = Console.ReadLine();

                    Console.WriteLine("How many ingredients does the " + recipeName + " consist of? "); //THIS STATEMENT WILL ALLOW THE USER TO PROVIDE THE NUMBER OF INGREDIENTS
                    NumberOfIngredients = int.Parse(Console.ReadLine());

                    /*RecipeSteps = new List<string>(); //AN ARRAY THAT WILL STORE THE RECIPE STEPS
                    IngredientQuantities =*/

                    
                    //THE FOLLOWING IS A FOR-LOOP THAT WILL ALLOW THE USER TO ENTER THE INGREDIENTS IN SEQUENCE
                    for (int i = 0; i < NumberOfIngredients; i++)
                    {
                        int sum = 1 + i;
                        Console.WriteLine("Enter ingredient #" + sum);
                        IngredientNames.Add(Console.ReadLine());
                        Console.WriteLine("Provide the number of calories: ");
                        Calories.Add(Convert.ToInt32(Console.ReadLine()));
                        Console.WriteLine("State the quantity: ");
                        IngredientQuantities.Add(Convert.ToInt32(Console.ReadLine()));
                        Console.WriteLine("Enter the food group this ingredient belongs to: ");
                        FoodGroup.Add(Console.ReadLine());
                        Console.WriteLine("Provide the unit of measure for " + IngredientNames[i] + ": ");
                        IngredientUnitofMeasure.Add(Console.ReadLine());
                        TotalCalories = Calories[i] + TotalCalories;
                    }
                    if (TotalCalories > 300) 
                    {
                        Console.WriteLine("Please note that the recipe exceeds 300 calories!");
                    }


                    Console.WriteLine("Enter the number of steps associated with this recipe: ");
                    NumberOfsteps = int.Parse(Console.ReadLine());

                    //THIS SECOND FOR-LOOP WILL ALLOW THE USER TO PROVIDE THE RECIPE STEPS IN SEQUENCE
                    for (int y = 0; y < NumberOfsteps; y++)
                    {
                        int step = 1 + y;
                        Console.WriteLine("Enter step #" + step + " of your recipe: ");
                        RecipeSteps.Add(Console.ReadLine());
                    }
                }
                else if (MenuSelection == 2)
                {
                    obj.RecipeDisplay(IngredientNames, RecipeSteps, IngredientQuantities, IngredientUnitofMeasure, recipeName, FoodGroup, TotalCalories);
                }
                else if (MenuSelection == 3)
                {
                    obj.RecipeScale(IngredientQuantities, NumberOfIngredients, IngredientNames, IngredientUnitofMeasure, FoodGroup, TotalCalories);
                    //obj.RecipeDisplay(IngredientNames, RecipeSteps, IngredientQuantities, IngredientUnitofMeasure, recipeName, FoodGroup, TotalCalories);
                }
                else if (MenuSelection == 4)
                {
                    obj.ValueReset(IngredientQuantities, IngredientNames);
                }
                else if (MenuSelection == 5)
                {
                    obj.DeleteValues(IngredientQuantities, RecipeSteps, IngredientNames, IngredientUnitofMeasure, recipeName);
                } 
                else if (MenuSelection == 6) 
                {
                    Environment.Exit(0); //THIS STATEMENT WILL TERMINATE THE PROGRAM UPON EXECUTION
                }
                else
                {
                    Console.WriteLine("Invalid input! Please select from the available options.");
                }
                }
            
        }
        }
    public class External
    {

        //VARIABLE DECLARATIONS
        string recipeName, IngredientUnitofMeasure, UserInput;
        int NumberOfIngredients = 0;

        public string DeleteValues(List<int> IngredientQuantities, List<string> RecipeSteps, List<string> IngredientNames, List<string> IngredientUnitofMeasure, string recipeName)
        {

            if (IngredientNames.Count == 0)
            {
                Console.WriteLine("Your cookbook is empty, please enter a recipe!");
            }
            else
            {
                Console.WriteLine("Are you sure you wish to delete all existing data [Y] or [N]: ");
                String Input = Console.ReadLine().ToUpper();

                if (Input.Equals("Y"))
                {
                    recipeName = string.Empty;
                    IngredientUnitofMeasure.Clear();
                    IngredientQuantities.Clear();
                    RecipeSteps.Clear();
                    IngredientNames.Clear();
                    Console.WriteLine("All data has been successfully cleared!");

                }
                else if (Input.Equals("N"))
                {

                }
            }


            return "";
        }

        public string RecipeDisplay(List<string> IngredientNames, List<string> RecipeSteps, List<int> IngredientQuantities, List<string> IngredientUnitofMeasure, string recipeName, List<string> FoodGroup, int TotalCalories)
        {

            if (IngredientNames.Count == 0)
            {
                Console.WriteLine("Your cookbook is empty, please enter a recipe!");
            }
            else
            {
                Console.WriteLine("Recipe name: " + recipeName);

                for (int i = 0; i < IngredientNames.Count; i++)
                {
                    Console.WriteLine("Ingredient: " + IngredientNames[i] + "\n" +
                                      "Quantity: " + IngredientQuantities[i] + "\n" +
                                      "Unit of measure: " + IngredientUnitofMeasure[i] + "\n" +
                                      "Food group: " + FoodGroup[i] + "\n" +
                                      "Total number of calories: " + TotalCalories);
                }

                foreach (string i in RecipeSteps)
                {
                    Console.WriteLine("Steps: \n" +
                                      i);
                }
            }

            return "";

        }

        public string RecipeInformation(List<int> IngredientQuantities, List<int> NumberOfIngredients, List<string> IngredientNames, string NumberOfsteps)
        {
            return "";
        }

        public int RecipeScale(List<int> IngredientQuantities, int NumberOfIngredients, List<string> IngredientNames, List<string> IngredientUnitofMeasure, List<string> FoodGroup, int TotalCalories)
        {

            double Factor;
            List<int> NewIngredientQuantites = new List<int>();

            if (IngredientNames.Count == 0)
            {
                Console.WriteLine("Please enter a recipe before attempting to scale.");
            }
            else
            {
                Console.WriteLine("Which scale do you wish to scale your recipe? (CHOOSE EITHER 0.5, 2 OR 3");
                Factor = double.Parse(Console.ReadLine());
                //int ScaleFactor = Convert.ToInt32(Factor);

                if (Factor == 0.5)
                {
                    for (int i = 0; i < IngredientQuantities.Count; i++)
                    {
                        NewIngredientQuantites.Add(IngredientQuantities[i] / 2);
                    }
                    Console.WriteLine("Your recipe has been scaled by " + Factor + " successfully!");
                }
                else if (Factor == 2)
                {
                    for (int i = 0; i < IngredientQuantities.Count; i++)
                    {
                        NewIngredientQuantites.Add(IngredientQuantities[i] * 2);
                    }
                    Console.WriteLine("Your recipe has been scaled by " + Factor + " successfully!");
                }
                else if (Factor == 3)
                {
                    for (int i = 0; i < IngredientQuantities.Count; i++)
                    {
                        NewIngredientQuantites.Add(IngredientQuantities[i] * 3);
                    }
                    Console.WriteLine("Your recipe has been scaled by " + Factor + " successfully!");
                }
                else
                {
                    Console.WriteLine("Invalid!");
                }
            }
            for (int i = 0; i < IngredientNames.Count; i++)
            {
                Console.WriteLine("Updated recipe information: \n" +
                                  "" +
                                  "Ingredient: " + IngredientNames[i] + "\n" +
                                  "Quantity: " + NewIngredientQuantites[i] + "\n" +
                                  "Unit of measure: " + IngredientUnitofMeasure[i] + "\n" +
                                  "Food group: " + FoodGroup[i] + "\n" +
                                  "Total number of calories: " + TotalCalories);
            }

            return 0;
        }
        public string ValueReset(List<int> IngredientQuantities, List<string> IngredientNames)
        {

            if (IngredientNames.Count == 0)
            {
                Console.WriteLine("Your cookbook is empty, please enter a recipe!");
            }
            else
            {
                Console.WriteLine("Enter [Y] to confirm that you wish to reset the quanity values");
                string Input = Console.ReadLine();

                if (Input.Equals("Y") || Input.Equals("y"))
                {
                    IngredientQuantities.Clear();
                    Console.WriteLine("Values reset successfully!");
                }
            }


            return "";
        }
    }

        }

    
    
